import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Othello implements ActionListener { //PLAYER STARTS AS BLACK !!

	//MEMBER VARIABLES - (NEARLY) ALL COMPONENTS
	JFrame window = new JFrame();
	JLabel infobar = new JLabel();
	JPanel board = new JPanel(new GridLayout(8,8));
	Tile[][] tileArray = new Tile[8][8];
	Board TileBoard; //init Board object
	JButton greedyAI = new JButton("Greedy AI (play color)");
	JPanel boardConstrain = new JPanel( new GridBagLayout()); //board is within container to maintain square-ness
	int turn = 1; //whose turn is it - start with white, refresh flips it to black to start

	public Othello() {
		
		TileBoard = new Board(this);
		
		for(int i=0;i<64;i++) {
			Tile blank = new Tile("green", new Coordinate(i/8, i%8), this, TileBoard); //refresh color
			tileArray[i/8][i%8] = blank; //i integer div 8 = row, i mod 8 = column
		}
		
		window.setTitle("Othello - Oisin Goddard psyog2");
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setLayout(new BorderLayout()); //compass directions layout
		
		JLabel infobar = new JLabel( this.turnToString() + " player - do something");
		infobar.setBorder( new EmptyBorder(0,5,2,5));
		window.add(infobar, BorderLayout.NORTH);	
		
		greedyAI.addActionListener(this);
		
		this.refresh();
	}
	
	public void refresh() {
		
		this.changeTurn();
		//TileBoard.rotateBoard(); //removed cus its ugly

		infobar.setText(this.turnToString() + " player - do something");
		window.add(infobar, BorderLayout.NORTH);
		
		for(int i=0;i<64;i++) { //refresh and print board
			TileBoard.getTile( new Coordinate(i/8, i%8) ).refresh(); //refresh colours and icons
			board.add( TileBoard.getTile( new Coordinate(i/8, i%8) ) ); //add tiles to board
		}
		
		boardConstrain.add(board);
		board.setBorder(BorderFactory.createLineBorder(Color.black));
		window.add(board, BorderLayout.CENTER); //Adding the board itself, skipping constraint
		
		window.add(greedyAI, BorderLayout.SOUTH);
		

		window.revalidate();
		window.repaint();
		
		window.setResizable(false);
		window.setSize( new Dimension(315,365)); //TODO make board stay square
		window.setLocationRelativeTo(null);
		window.setVisible(true);
		
		if(TileBoard.isOver()) {
			this.gameOver();	
		}
	}
	
	public int getTurn() {
		return turn;
	}
	
	public void changeTurn() {
		turn = turn * -1;
	}

	public static void main(String[] args) {
		Othello game = new Othello(); //start a non-static game instance
	}
	
	public String turnToString() {
		String turnStr = "";
		if(turn == -1) {
			turnStr = "black";
		} else if (turn == 1) {
			turnStr = "white";
		}
		return turnStr;
	}
	
	private void gameOver() {
		System.out.println("Game over!");
	}
	
	public void actionPerformed(ActionEvent ae) {
		Tile search;
		for (int i=0; i<64; i++) { //search for valid moves
			search = TileBoard.getTile( new Coordinate(i/8, i%8));
			if(TileBoard.isValid(search)) { //if this move is valid
				//run actionEvent from here
				
				if( search.getColour() == 0 && TileBoard.isValid(search) ) { //only make changes if the move is blank and valid
					if(search.getColour() == 0) {
						search.setColour(this.getTurn());
					}
					
					this.refresh(); //refresh to show placement
				
					Tile[] runArray = TileBoard.findRun(search);
					if( runArray.length == 6 ) { //if it was a sucessful run
						for (Tile runTile : runArray) {
							runTile.setColour(search.getColour()); //flip the colours
						}
					}
					this.refresh();
				}
				
			}
		}
	}

}
