import java.util.Arrays;

public class Board { //board is aggregated by Othello
	
	private Tile[][] tileArray = new Tile[8][8];
	private Othello game;
	
	public Board(Othello gameInst) {
		
		game = gameInst;
		
		for(int i=0;i<64;i++) {
			Tile blank = new Tile("green", new Coordinate(i/8, i%8), game, this); //refresh color
			tileArray[i/8][i%8] = blank; //i integer div 8 = row, i mod 8 = column
		}
		
		tileArray[3][3].setColour("white");
		tileArray[4][4].setColour("white");
		tileArray[3][4].setColour("black");
		tileArray[4][3].setColour("black"); //add 4 initial pieces to center of board
	}
	
	public Tile getTile(Coordinate coord) { //getter for Board Tiles
		return(tileArray[coord.getRow()][coord.getCol()]);
	}
	
	public int getTileCol(Coordinate coord) { //getter for Board Tiles' colour int
		return(tileArray[coord.getRow()][coord.getCol()].getColour());
	}
	
	public boolean isValid(Tile move) { //assess if a tile is a valid move

		Tile[] spaces = new Tile[] { move.getNeighbour("north"), //fetch all adjacent tiles to array for looping
									move.getNeighbour("east"),
									move.getNeighbour("south"),
									move.getNeighbour("west"), };

		for (Tile space : spaces) { //evaluate (given their coordinates are valid) if the space is unoccupied
			if (space.getCoords().isValid() && space.getColour() == game.getTurn()*-1) { //if position is valid and space is occupied by opposition
				return true; //if at least one position is occupied it is instantly valid
			}
		}
		return false; //return the array of coordinates
	}
	
	public boolean isOver() { //method to check if Board is full. Upon first appearance of a blank tile false is returned.
		boolean full=false;
		
		for (int i=0;i<64;i++) {
			if(tileArray[i/8][i%8].getColour() != 0) {
				full=false;
			}
		}
		
		if(full == false) {
			for(int i=0; i<64;i++) {
				if(this.getTile( new Coordinate(i/8,i%8) ).isValid()) {
					return false;
				}
			}
		}
		
		return true;
	}
	
	public void rotateBoard() { //rotate board by 180* for next player. Not a getter instead a function on the board itself
    	Tile[][] target = new Tile[tileArray.length][tileArray[0].length];
    	
    	for(int row=0; row<tileArray.length; row++) {
    		for(int col=0; col<tileArray[0].length; col++) {
    			target[row][col] = tileArray[tileArray.length - row - 1][tileArray[0].length - 1 - col];
    		}
    	}
    	tileArray = target;
    }
	
	public Tile[] findRun(Tile move) { //TODO given a move, find any runs of potential flips. Returns array of tiles in the run, excluding boundary friendly pieces
		
		Tile inspect = move; //copy for each iteration
		Tile[] run = new Tile[6]; //max size 6, from one end to another
		int runCount = 0; //counter to add to correct position of run
		
		for( String dir : new String[] {"north","east","south","west"}) { //cycle through the different directions
			while ( inspect.getNeighbour(dir).getColour() == move.getColour()*-1) { //loop - while the (direction) neighbour is different colour, keep going that way 
				inspect = inspect.getNeighbour(dir);
				run[runCount] = inspect; //add this enemy tile to list
				runCount++;
				}
			//after loop, the run has encountered a non-enemy piece
			if(inspect.getNeighbour(dir).getColour() == move.getColour()) { //if it is friendly, it is a successful run, return it
				return run;
			} else { //if not, reset appropriate values and the for-each loop reiterates
				runCount = 0;
				Arrays.fill(run, null);
			}
		}
		
		
		return ( new Tile[0]); //return array indicating no run
	}
}