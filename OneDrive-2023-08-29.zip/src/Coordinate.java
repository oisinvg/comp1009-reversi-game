public class Coordinate {

	//Datatype for Board coordinate
	
	private final int row, col;
	
	public Coordinate(int r, int c) {
		row = r;
		col = c;
	}
	
	public int[] getCoord() {
		return(new int[] {row, col}); //return coordinates as length 2 integer array
	}
	
	public int getRow() {
		return(row);
	}
	
	public int getCol() {
		return(col);
	}
	
	public boolean isValid() { //specifically for identifying valid move spaces in Board.validMove()
		if(row >= 0 && col >= 0) {
			return true;
		} else {
			return false;
		}
	}
	
	public Coordinate getNeighbour(String cardinal) {
		Coordinate neighbour = this;
		int row, col;
		
		if(cardinal == "north") { //fetch correct coordinates for a position neighbouring the passed coordinates
			neighbour = new Coordinate(this.getRow()-1, this.getCol() );			
		} else if (cardinal == "east") {
			neighbour = new Coordinate( this.getRow(), this.getCol()+1 );
		} else if (cardinal == "west") {
			neighbour = new Coordinate( this.getRow(), this.getCol()-1 );
		} else if (cardinal == "south") {
			neighbour = new Coordinate( this.getRow()+1, this.getCol() );
		}
		
		if(neighbour.isValid()) { //coordinates may contain negatives, so if they do, don't return the new neighbour coordinate
			return neighbour;
		} else {
			return this;
		}
	}
	
	public String toString() {
		return("("+row+", "+col+")");
	}

}
