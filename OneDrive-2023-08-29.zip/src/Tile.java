import javax.swing.*;
import java.awt.event.*;

public class Tile extends JButton implements ActionListener { //Tile is aggregated by Board
	
	private int colour;
	private Coordinate coordinate;
	private String imgDir = "C:\\Users\\oisin\\OneDrive\\Uni\\Computer Science\\Term 2\\COMP1009 - Programming Paradigms\\OO - Java\\Coursework\\img\\"; //path of img, for readability
	private Othello game;
	private Board TileBoard;

	public Tile(String colorStr, Coordinate coord, Othello gameInst, Board boardInst) { //parameters: String color, coordinate of Tile, game object it was created it, board object it belongs to
		
		super(); //call parent constructor
		
		game = gameInst;
		TileBoard = boardInst;
		coordinate = coord;
		
		if(colorStr == "green") { //initialise col value based on color passed 
			colour=0; //save state
		} else if(colorStr == "white") {
			colour=1;
		} else if(colorStr == "black") {
			colour=-1;
		}
		ImageIcon img = new ImageIcon("C:\\Users\\oisin\\OneDrive\\Uni\\Computer Science\\Term 2\\COMP1009 - Programming Paradigms\\OO - Java\\Coursework\\img\\"+colorStr+".png"); //get correct colour
		super.setIcon(img);
		super.addActionListener(this);
	}

	public void actionPerformed(ActionEvent ae) {
				
		if( this.colour == 0 && TileBoard.isValid(this) ) { //only make changes if the move is blank and valid
			if(colour == 0) {
				colour = game.getTurn();
			}
			
			game.refresh(); //refresh to show placement
		
			Tile[] runArray = TileBoard.findRun(this);
			if( runArray.length == 6 ) { //if it was a sucessful run
				for (Tile runTile : runArray) {
					runTile.setColour(this.getColour()); //flip the colours
				}
			}
			game.refresh();
		}
	}
	
	public void refresh() { //correct icon based on col int value
		if(colour == 0) {
			ImageIcon img = new ImageIcon(imgDir+"green.png");
			super.setIcon(img);
		} else if(colour == 1) {
			ImageIcon img = new ImageIcon(imgDir+"white.png");
			super.setIcon(img);
		} else if(colour == -1) {
			ImageIcon img = new ImageIcon(imgDir+"black.png");
			super.setIcon(img);
		}
	}
	
	public int getColour() {
		return(colour);
	}
	
	//set colour methods, String and int arg methods
	public void setColour(String newColour) {
		if(newColour == "green") {
			colour = 0;
		} else if(newColour == "white") {
			colour = 1;
		} else if(newColour == "black") {
			colour = -1;
		}
		this.refresh(); // update icon after
	}
		
	public void setColour(int newColour) {
		colour = newColour;
		this.refresh(); // update icon after
	}
	
	
	public Coordinate getCoords() {
		return coordinate;
	}
	
	public Tile getNeighbour(String cardinal) {
		return( TileBoard.getTile(this.getCoords().getNeighbour(cardinal)) );
	}
}